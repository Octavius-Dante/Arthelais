sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller){
    'use strict';
    return Controller.extend("ntt.hr.payroll.controller.View2",{
        onInit: function(){
            // So we are getting the same 
            this.Router = this.getOwnerComponent().getRouter();
        },

        onBack: function(){
            // this.getView().getParent().to("idView1");            
            this.Router.navTo("Master") ;
        }
    });
});