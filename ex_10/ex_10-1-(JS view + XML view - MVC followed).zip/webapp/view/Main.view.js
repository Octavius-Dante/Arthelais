sap.ui.jsview("chip.view.Main", {

    getControllerName: function() {
        return "chip.controller.Main";
    },

    createContent: function(oController) {
            var oInp = new sap.m.Input("idInp");
            //oInp.placeAt("canvas");
            var oBtn = new sap.m.Button('idBtn',
                {
                text: 'Shoot!',
                icon: 'sap-icon://camera'
                }
            );
            
            //oBtn.placeAt("content");
            var oBtn2 = new sap.m.Button({
                text: "Attach",
                press: oController.spiderman
            });

            //oBtn2.placeAt("next");
            return [oInp, oBtn, oBtn2];
    }

});