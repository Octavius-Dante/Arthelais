sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    return Controller.extend("chip.controller.MyXML",{
        onInit: function(){

        },
        //Ctrl+Slash /
        onBtnClick: function(){
                debugger;
                //var oInp = sap.ui.getCore().byId("idText");  //this.getView().byId("idText")
                var oInp = this.getView().byId("idText");
                alert(oInp.getValue());
            },
    });
});
