sap.ui.define([
	'sap/ui/core/UIComponent',
	'sap/ui/model/json/JSONModel',
	'sap/f/FlexibleColumnLayoutSemanticHelper', // Section -11
	'sap/f/library'
], function(UIComponent, JSONModel, FlexibleColumnLayoutSemanticHelper, fioriLibrary) { // section -11
	'use strict';

	return UIComponent.extend('sap.ui.demo.fiori2.Component', {

		metadata: {
			manifest: 'json'
		},

		init: function () {
			//////// Section~7 ////// Begin //////////
			var oModel,
				oProductsModel,	// Section 6
				oRouter;
			//////// Section~7 ////// End //////////	

			UIComponent.prototype.init.apply(this, arguments);

			//////// Section~7 ////// Begin //////////
			oModel = new JSONModel();
			this.setModel(oModel);
			//////// Section~7 ////// End //////////

			// set products demo model on this sample
			oProductsModel = new JSONModel();
			oProductsModel.setSizeLimit(1000);
			             // (Model-variable, model file name)
			this.setModel(oProductsModel, 'products'); // model file name is defined 
			oProductsModel.loadData("model/mockdata/products.json"); // Model file path is defined

			//////// Section~7 ////// Begin //////////
			oRouter = this.getRouter();
			oRouter.attachBeforeRouteMatched(this._onBeforeRouteMatched, this);
			oRouter.initialize();
			//////// Section~7 ////// End //////////			
		},

		//////// Section~11 ////// Begin //////////
		getHelper: function () {
			return this._getFcl().then(function(oFCL) {
				var oSettings = {
					defaultTwoColumnLayoutType: fioriLibrary.LayoutType.TwoColumnsMidExpanded,
					defaultThreeColumnLayoutType: fioriLibrary.LayoutType.ThreeColumnsMidExpanded
				};
				return (FlexibleColumnLayoutSemanticHelper.getInstanceFor(oFCL, oSettings));
			});
		},	
		//////// Section~11 ////// End //////////

		//////// Section~7 ////// Begin //////////
		_onBeforeRouteMatched: function(oEvent) {
			var oModel = this.getModel(),
				// sLayout = oEvent.getParameters().arguments.layout; -- section 10 
				sLayout = oEvent.getParameters().arguments.layout, 
				oNextUIState; // -- section 10

		//////// Section~11 ////// Begin //////////				
			// // If there is no layout parameter, set a default layout (normally OneColumn)
			// if (!sLayout) {
			// 	sLayout = fioriLibrary.LayoutType.OneColumn;
			// }

			// If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
			if (!sLayout) {
				this.getHelper().then(function(oHelper) {
					oNextUIState = oHelper.getNextUIState(0);
					oModel.setProperty("/layout", oNextUIState.layout);
				});
				return;
			}
		//////// Section~11 ////// End //////////
			oModel.setProperty("/layout", sLayout);
		},
		//////// Section~7 ////// End //////////
		
		//////// Section~11 ////// Begin //////////
		_getFcl: function () {
			return new Promise(function(resolve, reject) {
				var oFCL = this.getRootControl().byId('flexibleColumnLayout');
				if (!oFCL) {
					this.getRootControl().attachAfterInit(function(oEvent) {
						resolve(oEvent.getSource().byId('flexibleColumnLayout'));
					}, this);
					return;
				}
				resolve(oFCL);

			}.bind(this));
		}
		//////// Section~11 ////// End //////////
	});
});