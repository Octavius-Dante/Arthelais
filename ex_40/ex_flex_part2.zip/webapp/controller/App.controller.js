//////// Section~7 ////// Begin //////////
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.demo.fiori2.controller.App", {
		onInit: function () {
			this.oOwnerComponent = this.getOwnerComponent();
			this.oRouter = this.oOwnerComponent.getRouter();
			this.oRouter.attachRouteMatched(this.onRouteMatched, this);
		},

		onRouteMatched: function (oEvent) {
			var sRouteName = oEvent.getParameter("name"),
				oArguments = oEvent.getParameter("arguments");
				
			this._updateUIElements(); // section -11

			// Save the current route name
			this.currentRouteName = sRouteName;
			this.currentProduct = oArguments.product;
			/////// Section ~ 9 //////// Begin ///////			
			this.currentSupplier = oArguments.supplier; // Section ~ 9 
			/////// Section ~ 9 //////// End ///////
		},

		onStateChanged: function (oEvent) {
			var bIsNavigationArrow = oEvent.getParameter("isNavigationArrow"),
				sLayout = oEvent.getParameter("layout");

				this._updateUIElements(); // section -11

			// Replace the URL with the new layout if a navigation arrow was used
			if (bIsNavigationArrow) {
				/////// Section ~ 9 //////// Begin ///////
				// this.oRouter.navTo(this.currentRouteName, {layout: sLayout, product: this.currentProduct}, true); 
				this.oRouter.navTo(this.currentRouteName, {layout: sLayout, product: this.currentProduct, supplier: this.currentSupplier}, true);
				/////// Section ~ 9 //////// End ///////
			}
		},

		////// Section-11 /////// Begin ///////
		// Update the close/fullscreen buttons visibility
		_updateUIElements: function () {
			var oModel = this.oOwnerComponent.getModel(),
				oUIState;
			this.oOwnerComponent.getHelper().then(function(oHelper) {
				oUIState = oHelper.getCurrentUIState();
				oModel.setData(oUIState);
			});
		},
		////// Section-11 /////// End ///////
		
		onExit: function () {
			this.oRouter.detachRouteMatched(this.onRouteMatched, this);
			////// Section-11 /////// Begin ///////
			this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
			////// Section-11 /////// End ///////
		}
	});
});
//////// Section~7 ////// End //////////
