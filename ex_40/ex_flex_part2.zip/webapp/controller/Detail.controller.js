
sap.ui.define([
	"sap/ui/core/mvc/Controller" //,
	// 'sap/f/library' // Section~9  --- section 11 commented  
// ], function (Controller, fioriLibrary) { // Section~9  added fiorilibrary variable 
], function (Controller) { // Section~11  removed fiorilibrary variable 
	"use strict";

	return Controller.extend("sap.ui.demo.fiori2.controller.Detail", {
		//////// Section~7 ////// Begin //////////
		onInit: function () {

			//////// Section~11 ////// Begin //////////
			// var oOwnerComponent = this.getOwnerComponent(); 
			// this.oRouter = oOwnerComponent.getRouter();
			// this.oModel = oOwnerComponent.getModel();
			this.oOwnerComponent = this.getOwnerComponent();
			this.oRouter = this.oOwnerComponent.getRouter();
			this.oModel = this.oOwnerComponent.getModel();
			//////// Section~11 ////// End //////////
		 

			this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
			/////// Section ~ 9 //////// Begin ///////	
			this.oRouter.getRoute("detailDetail").attachPatternMatched(this._onProductMatched, this);
			/////// Section ~ 9 //////// End ///////	
		},
		
		/////// Section ~ 9 //////// Begin ///////	
		onSupplierPress: function (oEvent) {
			var supplierPath = oEvent.getSource().getBindingContext("products").getPath(),
				// supplier = supplierPath.split("/").slice(-1).pop(); // Section - 11
				supplier = supplierPath.split("/").slice(-1).pop(), 
				oNextUIState; // Section - 11

			//////// Section~11 ////// Begin //////////
			// this.oRouter.navTo("detailDetail", {layout: fioriLibrary.LayoutType.ThreeColumnsMidExpanded, supplier: supplier, product: this._product}); 
			this.oOwnerComponent.getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(2);
				this.oRouter.navTo("detailDetail", {
					layout: oNextUIState.layout,
					supplier: supplier,
					product: this._product
				});
			}.bind(this));
			//////// Section~11 ////// End //////////
		},
		/////// Section ~ 9 //////// End ///////	

		_onProductMatched: function (oEvent) {
			this._product = oEvent.getParameter("arguments").product || this._product || "0";
			this.getView().bindElement({
				path: "/ProductCollection/" + this._product,
				model: "products"
			});
		},
		//////// Section~7 ////// End //////////

		//////// Section~6 ////// Begin //////////
		onEditToggleButtonPress: function() {
			var oObjectPage = this.getView().byId("ObjectPageLayout"),
				bCurrentShowFooterState = oObjectPage.getShowFooter();

			oObjectPage.setShowFooter(!bCurrentShowFooterState);
		},
		//////// Section~6 ////// End //////////

		
		//////// Section~11 ////// Begin //////////
		handleFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
		},

		handleExitFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
		},

		handleClose: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
			this.oRouter.navTo("master", {layout: sNextLayout});
		},
		//////// Section~11 ////// End //////////


		//////// Section~7 ////// Begin //////////
		onExit: function () {
			this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		}
		//////// Section~7 ////// End //////////

	});
});
