sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"sap/f/library"		// Detail view is accessed using this library
], function (Controller, Filter, FilterOperator, Sorter, MessageBox, fioriLibrary) {
	"use strict";

	return Controller.extend("sap.ui.demo.fiori2.controller.Master", {
		onInit: function () {
			this.oView = this.getView();
			this._bDescendingSort = false;
			this.oProductsTable = this.oView.byId("productsTable");
			//////// Section~7 ////// Begin //////////
			this.oRouter = this.getOwnerComponent().getRouter();
			//////// Section~7 ////// End //////////
		},

		onSearch: function (oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");

			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("Name", FilterOperator.Contains, sQuery)];
			}

			this.oProductsTable.getBinding("items").filter(oTableSearchState, "Application");
		},

		onAdd: function () {
			MessageBox.information("This functionality is not ready yet.", {title: "Aw, Snap!"});
		},

		onSort: function () {
			this._bDescendingSort = !this._bDescendingSort;
			var oBinding = this.oProductsTable.getBinding("items"),
				oSorter = new Sorter("Name", this._bDescendingSort);

			oBinding.sort(oSorter);
		},

		// Detailed view is accessed on click		
		onListItemPress: function (oEvent) {
			//////// Section~7 ////// Begin //////////
			var productPath = oEvent.getSource().getBindingContext("products").getPath(),
				// product = productPath.split("/").slice(-1).pop(); // Section - 11
				 product = productPath.split("/").slice(-1).pop(), 
				 oNextUIState; // Section - 11
						
			//////// Section~11 ////// Begin //////////
			// this.oRouter.navTo("detail", {layout: fioriLibrary.LayoutType.TwoColumnsMidExpanded, product: product}); 
			//////// Section~7 ////// End //////////
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				this.oRouter.navTo("detail", {
					layout: oNextUIState.layout,
					product: product
				});
			}.bind(this));
			//////// Section~11 ////// End //////////

		}
	});
});
