sap.ui.define([
	'sap/ui/core/UIComponent',
	'sap/ui/model/json/JSONModel'
], function(UIComponent, JSONModel) {
	'use strict';

	return UIComponent.extend('sap.ui.demo.fiori2.Component', {

		metadata: {
			manifest: 'json'
		},

		init: function () {
			var oProductsModel;

			UIComponent.prototype.init.apply(this, arguments);

			// set products demo model on this sample
			oProductsModel = new JSONModel();
			oProductsModel.setSizeLimit(1000);
			             // (Model-variable, model file name)
			this.setModel(oProductsModel, 'products'); // model file name is defined 
			oProductsModel.loadData("model/mockdata/products.json"); // Model file path is defined

		}
	});
});