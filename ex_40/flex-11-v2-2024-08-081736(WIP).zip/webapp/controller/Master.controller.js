sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/odata/ODataModel'
], function (Controller, Filter, FilterOperator, Sorter, MessageBox, JSONModel, ODATAModel) {
	"use strict";

	return Controller.extend("sap.ui.demo.fiori2.controller.Master", {
		onInit: function () {	
			this.oView = this.getView();
			this._bDescendingSort = false;
			this.prod_total = 0;
			this.oProductsTable = this.oView.byId("productsTable");
			this.oRouter = this.getOwnerComponent().getRouter();

			// Local Json Model
			this.oFinModel = new JSONModel();
			this.oFinModel.setData({
				"products": []
			})
			this.getView().setModel(this.oFinModel, "viewModel");
			
			// Odata model pulling data from system
			var url = "/sap/opu/odata/sap/ZJUNE_19062024_SRV"
			var that = this;

			this.getView().setBusy(true);			
			var oModel = new ODATAModel(url, true);
			oModel.read("/ProductSet", {
				method: "GET",
				success: function (oData2, oResponse) {
					console.log(oResponse);
					
					that.getView().setBusy(false);

					// 02/july/2024  
					// Type 1 : Odata mapping to json model ~~ Works  
					// that.oFinModel.setData({
					// 	products: oData2.results
					// });
										
					// Type 2 : Odata mapping to json model ~~ works 
					that.oProductsTable.setModel(that.oFinModel.setData({
						products: oData2.results
					}));
					
					// Product total in Master view - Odata model
					// that.prod_total = oData2.results.length;
					// that.oFinModel.setProperty("/prod_count", that.prod_total);
					that.oFinModel.setProperty("/prod_count", oData2.results.length);
					
				},
				error: function (oError) {
					that.getView().setBusy(false);
					console.log(oError);
				}
			});						
		},

		onSearch: function (oEvent) {

			// var oTableSearchState = [],
			// 	sQuery = oEvent.getParameter("query");

			// if (sQuery && sQuery.length > 0) {
			// 	oTableSearchState = [new Filter("Name", FilterOperator.Contains, sQuery)];
			// }

			// this.oProductsTable.getBinding("items").filter(oTableSearchState, "Application");

		
			// A global Filter for Local Json Model mapped from odata 
			// so we can use as many filters as we want for all the fields ~~ Working 
			///////////////////////////////////////////////////////////////////////////////////////
			const sQuery = oEvent.getParameter("query");
			this._oGlobalFilter = null;

			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("NAME", FilterOperator.Contains, sQuery),
					new Filter("PRODUCT_ID", FilterOperator.Contains, sQuery),
					new Filter("CURRENCY_CODE", FilterOperator.Contains, sQuery),
					new Filter("CATEGORY", FilterOperator.Contains, sQuery)
				], false);
			}
			this._filter();
		},

		_filter: function() {
			let oFilter = null;
				oFilter = this._oGlobalFilter;
			this.oProductsTable.getBinding("items").filter(oFilter, "Application");
		},
		///////////////////////////////////////////////////////////////////////////////////////

		onAdd: function () {
			MessageBox.information("This functionality is not ready yet.", { title: "Aw, Snap!" });
		},

		onSort: function () {
			this._bDescendingSort = !this._bDescendingSort;
			var oBinding = this.oProductsTable.getBinding("items"),
				oSorter = new Sorter("NAME", this._bDescendingSort); 

			oBinding.sort(oSorter);
		},

		onListItemPress: function (oEvent) {
			var productPath = oEvent.getSource().getBindingContext("viewModel").getPath(), 
				product = productPath.split("/").slice(-1).pop(),
				oNextUIState;
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				debugger;
				this.oRouter.navTo("detail", {
					layout: oNextUIState.layout,
					product: product
				});
			}.bind(this));
		}
	});
});
