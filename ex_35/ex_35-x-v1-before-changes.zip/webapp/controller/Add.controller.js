sap.ui.define([
    'sap/ui/core/mvc/Controller',
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
], function(Controller, MessageBox, MessageToast, JSONModel) {
    'use strict';
    return Controller.extend("emc.hr.payroll.controller.Add",{
        onInit: function(){
            var oModel = new JSONModel();
            oModel.setData({
                "productData": {

                "PRODUCT_ID": "",
                "TYPE_CODE": "PR",
                "CATEGORY": "Notebooks",
                "NAME": "<Enter Name>",
                "DESCRIPTION": "<Enter description>",
                "SUPPLIER_ID": "0100000046",
                "SUPPLIER_NAME": "SAP",
                "TAX_TARIF_CODE": "1 ",
                "MEASURE_UNIT": "EA",
                "PRICE": "956",
                "CURRENCY_CODE": "USD",
                "DIM_UNIT": "CM",                    
                }
            })
            // setthing this model to view
            this.getView().setModel(oModel, "viewModel");
        },

        onSave: function(){
            MessageBox.confirm("This functionality is under construction");
        }
    });
});