//AMD Like Syntax, Module Definition, Scaffolding template
sap.ui.define(
    ['sap/ui/core/mvc/Controller'], 
    function(Controller){
        return Controller.extend("chip.controller.Main",{
            //this.getView()
            //Hook methods
            onInit: function() {
               //If you give more what you get, soon you will get
               //more than you gave 
               console.log("Contructor was called ");
               console.log(this.getView());
            },
            onExit: function(){
                console.log("onExit was called");
            },
            onBeforeRendering: function(){
                console.log("Before rendering was called ");
            },
            onAfterRendering: function(){
                console.log("After Rendering was called ");
                $("#idInp").fadeOut(1000).fadeIn(5000);
            },
            spiderman: function(){
                    //Step 1: get the object of Button 1 
                    var oBtnNew = sap.ui.getCore().byId("idBtn");
                    //Step 2: Attach the event dynamically to function
                    oBtnNew.attachPress(function(){
                        //alert(document.getElementById("idInp").value);
                        //Step 1: get the application object(instance)
                        var oCore = sap.ui.getCore();
                        //Step 2: Obtain the UI5 control object - sap.ui.getCore().byId("idInp")
                        var oInp = oCore.byId("idInp");
                        //Step 3: We have a value, so we will have setter and getter for same
                        var sVal = oInp.getValue();
                        //Step 4: print on screen
                        alert(sVal);
                    });
                }
        });
});