sap.ui.define([
    // 'sap/ui/core/mvc/Controller'
    'ntt/hr/payroll/controller/BaseController',
//////////////////////////////////////////////////    
    "sap/ui/core/Fragment"
//////////////////////////////////////////////////    
], function(Controller, Fragment){
    'use strict';
    return Controller.extend("ntt.hr.payroll.controller.View2",{
        onInit: function(){
            // So we are getting the same 
            this.oRouter = this.getOwnerComponent().getRouter();
            // this.Router.getRoute("Detail").attachPatternMatched(this.hercules);
            this.oRouter.getRoute("Detail").attachPatternMatched(this.hercules, this);
        },

        onBack: function(oEvent){
            // this.getView().getParent().to("idView1");  
            this.oRouter.navTo("Master") ;          
        },

        hercules: function(oEvent){
            // debugger;
            // var fruitId =  oEvent.getParameter("arguments").fruitId;
            // var sPath = '/fruits/' + fruitId;
            var sPath = this.extractPath(oEvent);
            this.getView().bindElement(sPath); // Binding with /fruits/<fruitID> - absolute path
        },

        onLinkPress: function(oEvent){
            var sText = oEvent.getSource().getText(); // getting the text from the source using event object
            sText = 'https://google.com?q=' + sText; // google search query with link text
            window.open(sText); // open another window
        },
        
        onF4help: function(){
            // alert('This functionality under construction');
            Fragment.load({
                name: "ntt.hr.payroll.fragments.popup",
                type: "XML",
                id: 'city',
                controller: this // Controller access is provided to the popup
            })
            // Asynchronous - 1.Call back and 2.Promise
            .then(function(oPopup){ // this oPopup object is an object of Select dialog control of fragments view
             // .then -- promise    
                oPopup.setTitle("Select City");
                oPopup.open();
            });
        },

        onFilter: function(){
            // alert('This functionality under construction');
            Fragment.load({
                name: "ntt.hr.payroll.fragments.popup",
                type: "XML",
                id: 'supplier',
                controller: this // Controller access is provided to the popup
            })
            // Asynchronous - 1.Call back and 2.Promise
            .then(function(oSupplier){ // this oPopup object is an object of Select dialog control of fragments view
                // .then -- promise    
                oSupplier.setTitle("Select Supplier");
                oSupplier.open();
            });
        }
        
    });
});