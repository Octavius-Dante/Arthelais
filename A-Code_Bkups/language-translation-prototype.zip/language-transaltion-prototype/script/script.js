

//setup before functions
var typingTimer;                //timer identifier
var doneTypingInterval = 5000;  //time in ms (5 seconds)

// const inputTextField = document.querySelector("#input-field");
var myInput = document.getElementById('input-field');
const inputTextArea = document.querySelector("#input-text");
var TextElem1 = "text variable"; // input field 
var TextElem2 = "text variable"; // input text area
var outText1 = "text variable";  // output for field  - console
var outText2 = "text variable";  // output for text area - console
var textX = "text variable";


//on keyup, start the countdown
myInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    if (myInput.value) {
        typingTimer = setTimeout(doneTyping(myInput.value), doneTypingInterval);
    }
});

//user is "finished typing," do something
function doneTyping (textX) {
    //do something
    const inputText = textX;
    const inputLanguage = "en";
    const outputLanguage = "ta"
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${inputLanguage}&tl=${outputLanguage}&dt=t&q=${encodeURI(inputText,)}`;

    fetch(url)
    .then((response) => response.json())
    .then((json) => {
      outText1 = json[0].map((item) => item[0]).join("");
      console.log(outText1);
    })
    .catch((error) => {
      console.log(error);
    });

}

inputTextArea.addEventListener("input", (e) => {
    TextElem2 = inputTextArea;
    translate(TextElem2);
  });

//user is "finished typing," do something
function translate(textX){
    //do something

    const inputText = textX.value;
    const inputLanguage = "en";
    const outputLanguage = "ta"
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${inputLanguage}&tl=${outputLanguage}&dt=t&q=${encodeURI(inputText,)}`;

    fetch(url)
    .then((response) => response.json())
    .then((json) => {
      outText2 = json[0].map((item) => item[0]).join("");
      console.log(outText2);
    })
    .catch((error) => {
      console.log(error);
    });

}