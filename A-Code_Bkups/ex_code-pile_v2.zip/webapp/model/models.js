sap.ui.define(['sap/ui/model/json/JSONModel'], // Dependency asynchronous module definition (AMD)
    function (JSONModel) {
        'use strict';
        // 'use strict' is declaration instruction to throw error 
        // if mentioned it will throw error when a value is assigned without declaration
        return {
            createJSONModel: function () {
                // Step 1. create a brand new model object
                var oModel = new JSONModel();
                // Step 2. Load or set the data to the model
                // oModel.setData();
                oModel.loadData("model/mockdata/sample.json");
                return oModel;
            },
            createXMLModel: function () {
            },
            createResourceModel: function () {
            }
        };
    });