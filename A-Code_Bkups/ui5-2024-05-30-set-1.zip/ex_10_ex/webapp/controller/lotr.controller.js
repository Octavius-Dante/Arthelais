//AMD Like Syntax, Module Definition, Scaffolding template
sap.ui.define(
    ['sap/ui/core/mvc/Controller'], 
    function(Controller){
        return Controller.extend("logger.controller.lotr",{

            onInit: function() {
            },
            onExit: function(){
            },
            onBeforeRendering: function(){
            },
            onAfterRendering: function(){
            },

            // XML view controlelr logic 
            onBtnClick: function(){
                // debugger;
                // var oInp = this.getView().byId("idInp1");

                this.getView().byId("idInp1").setValue("Some thing");  
                this.getView().byId("idInp2").setValue("Is Cooking!");  
                this.getView().byId("idInp3").setValue("Well @%&*$!");                
                // alert(oInp.getValue());
            }
        });
});