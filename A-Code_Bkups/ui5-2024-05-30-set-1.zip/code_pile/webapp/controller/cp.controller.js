sap.ui.define(
    ['sap/ui/core/mvc/Controller',
        'logger/model/models'],
    function (Controller, Models) {
        return Controller.extend("logger.controller.cp", {

            onInit: function () {

                this.getView().addStyleClass("sapUiSizeCompact") // Content density setting Compact 

                // Calling our own reuse calss to create model object
                var oModel = Models.createJSONModel("model/mockdata/sample.json"); // model path passed JSON 1 

                /////////////////////////////////////////////////////////
                // oModel.setDefaultBindingMode("Oneway");  // forcing the model to be oneway - doesn work in 25-05-22024
                /////////////////////////////////////////////////////////

                // Step 3. Make the model aware to the application
                // - Model settiing at application level - available in all the views     
                sap.ui.getCore().setModel(oModel); // a - model with no name is the default model 

                // - Model setting at View level - only specific to the view
                // - this.getView().setModel(oModel);    

                // Step 4. Binding Syntax Type 3, 4 
                ////////////////////////////////////////////////////                            

                /// for tabl control - row seelct operations - commented                 
                // // BINDING type 3
                // var oSalary = this.getView().byId("idSalary");
                // oSalary.bindValue('/empStr/Salary');

                // // BINDING type 4
                // var oCurr = this.getView().byId("idCurrency");
                // oCurr.bindProperty("value", "/empStr/Currency");
                /// for tabl control - row seelct operations - commented                 


                // Create JSON model 2 
                var oModel2 = Models.createJSONModel("model/mockdata/dataset.json"); // model path passed JSON 2

                // named model - we need to give a name
                sap.ui.getCore().setModel(oModel2, "got"); // a model with name               

                // This is not a Recommended - data model practice 
                // // Create XMl model 
                // var oXmlModel = Models.createXMLModel("model/mockdata/mydemo.xml")  // model path passed XML 
                // sap.ui.getCore().setModel(oXmlModel); // overrride with existingjson model

            },

            onLoad: function () {
                this.getView().byId("idEmpId").setValue("609879");
                this.getView().byId("idEmpName").setValue("Agamemnon Carlisle");
                this.getView().byId("idSalary").setValue("400000");
                this.getView().byId("idCurrency").setValue("USD");
            },

            onClear: function () {
                var oCval = this.getView().byId("idOutput").getValue();

                // this.getView().byId("idEmpId").setValue(" ");
                // this.getView().byId("idEmpName").setValue(" ");
                // this.getView().byId("idSalary").setValue(" "); 
                // this.getView().byId("idCurrency").setValue(" ");
                // this.getView().byId("idOutput").setValue(" ");

                this.getView().byId("idEmpId").setValue(null);
                this.getView().byId("idEmpName").setValue(null);
                this.getView().byId("idSalary").setValue(null);
                this.getView().byId("idCurrency").setValue(null);
                this.getView().byId("idOutput").setValue(null);
                alert("Data Cleared");

                // Variable Is Not Initial Check 
                if (typeof oCval === "string" && oCval.trim().length === 0) {
                } else {
                    alert("Concat value : " + oCval + " cleared");
                }
                // myStr = null                              
            },

            onLoad2: function () {
                this.getView().byId("idEmpId2").setValue("609880");
                this.getView().byId("idEmpName2").setValue("Laurent Billiard");
            },

            onClear2: function () {
                this.getView().byId("idEmpId2").setValue(" ");
                this.getView().byId("idEmpName2").setValue(" ");
                alert("Data Cleared");
            },

            onConcat: function () {
                // CONCATENATION GETTING VALUE FROM INPUT FIELDS
                var oVal1 = this.getView().byId("idEmpId").getValue();
                var oVal2 = this.getView().byId("idEmpName").getValue();
                this.getView().byId("idOutput").setValue(oVal1 + " " + oVal2);
            },

            onShow: function () {
                //Step 1 : Get the model object
                var oModel = sap.ui.getCore().getModel();

                //Step 2 : cahnge the data in the model 
                var objData = oModel.getProperty("/"); // get everything in the model
                console.log(objData);
                // oModel.setProperty("/empStr/empName", "Spiderman");
            },

            onFlip: function () {
                // debugger;
                var oModel = sap.ui.getCore().getModel();
                var oGOTModel = sap.ui.getCore().getModel("got");
                sap.ui.getCore().setModel(oGOTModel); // setting default model as GOT model
                sap.ui.getCore().setModel(oModel, "got"); // setting GOT model as Default model
            },

            onRowSelect: function (oEvent) {

                // oMinion is our event object now 
                console.log(oEvent);
                // Step 1 : What is the Row which was selected by user
                var oRowContext = oEvent.getParameter("rowContext");
                // Step 2 : Know the address of the element
                var sPath = oRowContext.getPath();
                // Step 3 : Get the object of the Simple form
                var oSimpleform = this.getView().byId("idSimple");
                // Step 4 : Perform Element Binding
                oSimpleform.bindElement(sPath);

            }

        });
    });