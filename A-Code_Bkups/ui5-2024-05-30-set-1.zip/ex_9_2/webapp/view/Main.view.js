sap.ui.jsview("chip.view.Main", {

    getControllerName: function() {
        return "chip.controller.Main";
    },

    createContent: function() {
            var oInp = new sap.m.Input("idInp");
            //oInp.placeAt("canvas");
            var oBtn = new sap.m.Button("idBtn",{
                text: "Shoot!",
                icon: "sap-icon://camera"
                // ,
                // press: function(){
                //     //alert(document.getElementById("idInp").value);
                //     //Step 1: get the application object(instance)
                //     var oCore = sap.ui.getCore();
                //     //Step 2: Obtain the UI5 control object - sap.ui.getCore().byId("idInp")
                //     var oInp = oCore.byId("idInp");
                //     //Step 3: We have a value, so we will have setter and getter for same
                //     var sVal = oInp.getValue();
                //     //Step 4: print on screen
                //     alert(sVal);
                // }
            });
            
            //oBtn.placeAt("content");
            var oBtn2 = new sap.m.Button({
                text: "Attach",
                press: function(){
                    //Step 1: get the object of Button 1 
                    var oBtnNew = sap.ui.getCore().byId("idBtn");
                    //Step 2: Attach the event dynamically to function
                    oBtnNew.attachPress(function(){
                        //alert(document.getElementById("idInp").value);
                        //Step 1: get the application object(instance)
                        var oCore = sap.ui.getCore();
                        //Step 2: Obtain the UI5 control object - sap.ui.getCore().byId("idInp")
                        var oInp = oCore.byId("idInp");
                        //Step 3: We have a value, so we will have setter and getter for same
                        var sVal = oInp.getValue();
                        //Step 4: print on screen
                        alert(sVal);
                    });
                }
            });

            //oBtn2.placeAt("next");
            return [oInp, oBtn, oBtn2];
    }

});