sap.ui.define(
    ['sap/ui/core/mvc/Controller',
        'logger/model/models',
        'logger/util/reuse'],
    function (Controller, Models, reuse) {
        return Controller.extend("logger.controller.ex16", {
            formatter : reuse, // Global variable
            onInit: function () {

                this.getView().addStyleClass("sapUiSizeCompact") // Content density setting Compact 

                // Calling our own reuse calss to create model object
                var oModel = Models.createJSONModel("model/mockdata/sample.json"); // model path passed 

                // - Model settiing at application level - available in all the views     
                sap.ui.getCore().setModel(oModel); // a - model with no name is the default model 

                // Create JSON model 2 
                var oModel2 = Models.createJSONModel("model/mockdata/dataset.json"); // model path passed 

                // named model - we need to give a name
                sap.ui.getCore().setModel(oModel2, "got"); // a model with name

                // Resource model 
                var oModelResource = Models.createResourceModel();
                // named model - we needd to give a name
                sap.ui.getCore().setModel(oModelResource, "i18n");

                // This is not a Recommended - data model practice 
                // Create XMl model 
                // var oXmlModel = Models.createXMLModel("model/mockdata/mydemo.xml")
                // sap.ui.getCore().setModel(oXmlModel); // overrride with existingjson model

                // // BINDING type 3
                // var oSalary = this.getView().byId("idSalary");
                // oSalary.bindValue('/empStr/Salary');

                // // BINDING type 4
                // var oCurr = this.getView().byId("idCurrency");
                // oCurr.bindProperty("value", "/empStr/Currency");

                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth()+1; //January is 0!
                var yyyy = today.getFullYear();
                var hour = today.getHours();
                var Minutes = today.getMinutes();
                var Seconds = today.getSeconds();
                var ampm = hour >= 12 ? 'PM' : 'AM';
                var hours = hour - 12;

// Type 1 conversion - 24 hours to  12 hours

                // if (ampm == 'PM'){
                //     var hours = hour - 12;
                // }else{
                //     var hours = 12 - hour;
                // }

// Type 2 conversion - 24 hours to  12 hours                
                // var hours = today.getHours();
                // hours = hours % 12;
                
                // 24 hour format
                var today1 = ( dd+'.'+mm+'.'+yyyy+' '+hour+':'+Minutes+':'+Seconds);
                
                // 12 hour format
                var today2 = ( dd+'.'+mm+'.'+yyyy+' '+hours+':'+Minutes+':'+Seconds+' '+ampm);
                
                this.getView().byId("idDate1").setValue(today); // default date from standard function
                this.getView().byId("idDate2").setValue(today1); //24 hours
                this.getView().byId("idDate3").setValue(today2); //24 hours
                

                // sap.ui.getCore().setModel(oModel2, "got"); // a model with name
                var oModel3 = sap.ui.getCore().getModel("got");
                var oDate = oModel3.getProperty("/empTab");
                debugger;
            },

            onLoad: function () {
                //Step 1 : Get the model object
                var oModel = sap.ui.getCore().getModel();

                //Step 2 : cahnge the data in the model 
                var objData = oModel.getProperty("/empStr"); // getting everything in the path of the structure 
                console.log(objData);
                oModel.setProperty("/empStr/empName", "Spiderman");
            },

            onShow: function () {
                //Step 1 : Get the model object
                var oModel = sap.ui.getCore().getModel();

                //Step 2 : cahnge the data in the model 
                var objData = oModel.getProperty("/"); // get everything in the model
                console.log(objData);
                // oModel.setProperty("/empStr/empName", "Spiderman");
            },

            onFlip: function () {
                // debugger;
                var oModel = sap.ui.getCore().getModel();
                var oGOTModel = sap.ui.getCore().getModel("got");
                sap.ui.getCore().setModel(oGOTModel);
                sap.ui.getCore().setModel(oModel, "got");
            },

            // Event handler function

            // event object as parameter good practise is oEvent
            onRowSelect: function (oEvent) {
                // oMinion is our event object now 
                console.log(oEvent);
                // Step 1 : What is the Row which was selected by user
                var oRowContext = oEvent.getParameter("rowContext");
                // Step 2 : Know the address of the element
                var sPath = oRowContext.getPath();
                // Step 3 : Get the object of the Simple form
                var oSimpleform = this.getView().byId("idSimple");
                // Step 4 : Perform Element Binding
                oSimpleform.bindElement(sPath);
            },

        });
    });

/// Exercise 14 -  change is here
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 