sap.ui.define([
    "sap/ui/core/format/NumberFormat",
    "sap/ui/core/format/DateFormat"
], function(NumberFormat, DateFormat) {
    'use strict';
    return{

        // Name formatting capital
        myFormatterFunction: function (input){
            if(input){
                return input.toUpperCase();
            }
        },

        // Currency formatting - from sap sdk
        formatCurrency: function(amount, currCode){
            var oCurrencyFormat = NumberFormat.getCurrencyInstance();
            return oCurrencyFormat.format(amount, currCode);
        },

        dateFormat: function (input){

        }

    }
});

