sap.ui.jsview("spiderman.view.Main", {

    // This is a fixed function of js view 
    getControllerName: function() {
        return "spiderman.controller.Main";
    },

    createContent: function() {

        var oBtn = new sap.m.Button("idBtn", {
            text: "Create Employee data",
            icon: "sap-icon://add-employee",
            // press: function () {}
        });

        var oBtn2 = new sap.m.Button({
            text: "Attach",
            icon: "sap-icon://validate",
            press: function() {
                // Step 1 : get the object of Button 1
                var oBtnNew = sap.ui.getCore().byId("idBtn");
                // Attach the event dynamically to the function
                oBtnNew.attachPress(function() {
                    alert(sap.ui.getCore().byId("idInp").getValue());
                });
            }
        });

        var oInp = new sap.m.Input("idInp");
        
        // oBtn.placeAt("content"); 
        // oInp.placeAt("content2");
        // oBtn2.placeAt("content3");

        // This is how the values are placed to web in JS view 
        return [oInp, oBtn, oBtn2];
        
    }
});