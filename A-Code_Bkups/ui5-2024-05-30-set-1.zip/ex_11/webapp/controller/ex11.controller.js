sap.ui.define(
    ['sap/ui/core/mvc/Controller'], 
    function(Controller){
        return Controller.extend("logger.controller.ex11",{

            onLoad: function(){
                this.getView().byId("idEmpId").setValue("609879");
                this.getView().byId("idEmpName").setValue("Argnan Carlyle");
                this.getView().byId("idSalary").setValue("400000"); 
                this.getView().byId("idCurrency").setValue("USD");
            },

            onClear: function(){
                this.getView().byId("idEmpId").setValue(" ");
                this.getView().byId("idEmpName").setValue(" ");
                this.getView().byId("idSalary").setValue(" "); 
                this.getView().byId("idCurrency").setValue(" ");                                
            }

        });
});