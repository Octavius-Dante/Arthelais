sap.ui.define(
    ['sap/ui/core/mvc/Controller',
    'logger/model/models'], 
    function(Controller, Models){
        return Controller.extend("logger.controller.ex12",{

            onInit: function(){            
                // Calling our own reuse calss to create model object
                var oModel = Models.createJSONModel();

                // Step 3. Make the model aware to the application
                // - Model settiing at application level - available in all the views     
                sap.ui.getCore().setModel(oModel);   

                 // - Model setting at View level - only specific to the view
                 // - this.getView().setModel(oModel);    
                 
            // Step 4. Binding Syntax Type 3, 4 
           ////////////////////////////////////////////////////                            
                // BINDING type 3
                var oSalary = this.getView().byId("idSalary");
                oSalary.bindValue('/empStr/Salary');
                
                // BINDING type 4
                var oCurr = this.getView().byId("idCurrency");
                oCurr.bindProperty("value", "/empStr/Currency");
            },

            onLoad: function(){
                this.getView().byId("idEmpId").setValue("609879");
                this.getView().byId("idEmpName").setValue("Argnan Carlyle");
                this.getView().byId("idSalary").setValue("400000"); 
                this.getView().byId("idCurrency").setValue("USD");
            },

        });
});