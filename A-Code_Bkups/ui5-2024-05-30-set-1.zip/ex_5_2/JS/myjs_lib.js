
    // ALert message based on script by events
    function demoFunction() {
      alert('Welcome to SAP Ui5');
    }

    function consoleFunction() {

      // to trigger a debugger based on If condiiton 
      var alpha = 20, beta = 30, gamma = alpha + beta;
      if (gamma > 40) {
        // debugger;
      }

      // Print in console for developers
      var x = 'Text for displaying console log message'
      console.log("This is a demo" + x);
      // console.log('test value');
    }

    // change the whole DOM and displaying the message
    function document_writeFunction(){
      document.write("Demo text message for document.write");
    }


    function access_elementFunction(){
      var oMsg = document.getElementById('msg');
      oMsg.innerText = "Hey what's up!";
    }

    function input_textFunction(){
      var oMsg = document.getElementById("label_text");
      var oInp = document.getElementById("max");
      oMsg.innerText = "Input field text is : " + oInp.value + " message showed";
    }

    // Validaiton of input fields
    function onLogin(){

      var oUser = document.getElementById("idUser");
      var sUser = oUser.value;

      // Chaining in JS - because getElementById returns an object 
      var sPass = document.getElementById("idPass").value;

      // var oPass = document.getElementById("idPass");
      // var sPass = oPass.value;

      // Single = equalto is for value assignment 
      // Double == equalto is for Compare value 
      // Triple === equalto is for Compare value and Data type

      if (sUser === "dante" && sPass === "dante"){
        document.write('Login success');
      }
      else {
        alert('Login failed try again!');
      }
    }

// change the color of titles
    function getClass(){
// Get all aelements in an array which has same class name
      var arrElements = document.getElementsByClassName("box-title");
// loop over an array and process one by one       
      for(var i=0;i<arrElements.length;i++){
          var item = arrElements[i];
// cahnging CSS at runtime           
        item.style.backgroundColor = "black";
      }
    }

    function addNewElement(){
      // 1. Creare a brand new element
      var oElement = document.createElement("h4");      
      // 2. creaet a text node  // 3. add the text to the text node
      var oTextNode = document.createTextNode("Aristotle");   
      
      // Value is taken from input field
      // var oTextNode = document.createTextNode(document.getElementById("max").value);   
      
      // 4. append the text node to the newly creraetd element
      oElement.appendChild(oTextNode);
      // 5. get the canvas element object
      var oCanvas = document.getElementById("canvas");
      // 6. add our newly created element inside the canvas
      oCanvas.appendChild(oElement);

    }
