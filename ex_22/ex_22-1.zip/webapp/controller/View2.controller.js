sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller){
    'use strict';
    return Controller.extend("ntt.hr.payroll.controller.View2",{
        onInit: function(){
            // So we are getting the same 
            this.Router = this.getOwnerComponent().getRouter();
            // this.Router.getRoute("Detail").attachPatternMatched(this.hercules);
            this.Router.getRoute("Detail").attachPatternMatched(this.hercules, this);
        },

        onBack: function(oEvent){
            // this.getView().getParent().to("idView1");  
            this.Router.navTo("Master") ;          
        },

        hercules: function(oEvent){
            // debugger;
            var fruitId =  oEvent.getParameter("arguments").fruitId;
            var sPath = '/fruits/' + fruitId;
            this.getView().bindElement(sPath); // Binding with /fruits/<fruitID> - absolute path
        },
    });
});