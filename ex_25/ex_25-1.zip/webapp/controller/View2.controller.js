sap.ui.define([
    // 'sap/ui/core/mvc/Controller'
    'ntt/hr/payroll/controller/BaseController',
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (Controller, Fragment, Filter, FilterOperator) {
    'use strict';
    return Controller.extend("ntt.hr.payroll.controller.View2", {
        onInit: function () {
            // So we are getting the same 
            this.oRouter = this.getOwnerComponent().getRouter();
            // this.Router.getRoute("Detail").attachPatternMatched(this.hercules);
            this.oRouter.getRoute("Detail").attachPatternMatched(this.hercules, this);
        },

        onBack: function (oEvent) {
            // this.getView().getParent().to("idView1");  
            this.oRouter.navTo("Master");
        },

        hercules: function (oEvent) {
            // debugger;
            // var fruitId =  oEvent.getParameter("arguments").fruitId;
            // var sPath = '/fruits/' + fruitId;
            var sPath = this.extractPath(oEvent);
            this.getView().bindElement(sPath); // Binding with /fruits/<fruitID> - absolute path
        },

        onLinkPress: function (oEvent) {
            var sText = oEvent.getSource().getText(); // getting the text from the source using event object
            sText = 'https://google.com?q=' + sText; // google search query with link text
            window.open(sText); // open another window
        },
        // declaring a null variable for popup object
        oCityPopup: null,
        oSupplierPopup: null,

        onSearchPopup: function (oEvent) {

            var sId = oEvent.getSource().getId();
            if (sId.indexOf("city") !== -1) {
                // Step 1 : Get the seach string 
                var sVal1 = oEvent.getParameter("value");
                // Step 2 : get the popup object itself
                var oBinding1 = oEvent.getParameter("itemsBinding");
                // step 3 : prepare filter
                var oFilter1 = new Filter("cityName", FilterOperator.Contains, sVal1);
                // step 4 : pass filter to pop up items binding
                oBinding1.filter(oFilter1);
            }

            if (sId.indexOf("supplier") !== -1) {
                // Step 1 : Get the seach string 
                var sVal2 = oEvent.getParameter("value");
                // Step 2 : get the popup object itself
                var oBinding2 = oEvent.getParameter("itemsBinding");
                // step 3 : prepare filter
                var oFilter2 = new Filter("name", FilterOperator.Contains, sVal2);
                // step 4 : pass filter to pop up items binding
                oBinding2.filter(oFilter2);
            }
        },

        onConfirm: function (oEvent) {

            var sId = oEvent.getSource().getId();

            // F4 help object

            // finding the pattern 'city' in id value not equal to -1 
            if (sId.indexOf("city") !== -1) {
                // 1. Read the value which was selected in the popup
                var oSelectedItem = oEvent.getParameter("selectedItem");
                var sText = oSelectedItem.getLabel();
                // 2. place the value to the field INSIDE the TABLE
                // this.oSelectedField.setValue("Test Text value fill");
                this.oSelectedField.setValue(sText);
            }

            // Filter object 
            if (sId.indexOf("supplier") !== -1) {
                // 1. get teh table object
                var oTable = this.getView().byId("idTab");
                // 2. Read multi select items
                var aSelectedItems = oEvent.getParameter("selectedItems"); //array of multipel items
                // 3. Construct filter
                var aFilters = [];
                for (let index = 0; index < aSelectedItems.length; index++) {
                    const element = aSelectedItems[index];
                    const sText = element.getLabel();
                    aFilters.push(new Filter('name', FilterOperator.EQ, sText));
                }
                var oFilter = new Filter({
                    filters: aFilters,
                    and: false
                });
                // 4. Pump to binding
                oTable.getBinding("items").filter(oFilter);
                // alert("this is under construction");
            }
        },

        oSelectedField: null,
        onF4help: function (oEvent) {
            // when user clikc on F4 on the field inside the table, that field object
            // we are storing now in a temporary object
            this.oSelectedField = oEvent.getSource();

            // alert('This functionality under construction');
            if (!this.oCityPopup) {
                var that = this;
                Fragment.load({
                    name: "ntt.hr.payroll.fragments.popup",
                    type: "XML",
                    id: 'city',
                    controller: this // Controller access is provided to the popup
                })
                    // Asynchronous - 1.Call back and 2.Promise
                    .then(function (oPopup) { // this oPopup object is an object of Select dialog control of fragments view
                        // assign the object created by system to our global variable
                        that.oCityPopup = oPopup;
                        that.oCityPopup.setTitle("Select City");
                        that.getView().addDependent(that.oCityPopup);
                        that.oCityPopup.bindAggregation("items", {
                            path: '/cities',
                            template: new sap.m.DisplayListItem({
                                label: '{cityName}',
                                value: '{famousFor}'
                            })
                        });
                        that.oCityPopup.setMultiSelect(false);
                        that.oCityPopup.open();
                    });
            } else {
                this.oCityPopup.open();
            }
        },

        onFilter: function () {
            // alert('This functionality under construction');
            if (!this.oSupplierPopup) {
                var that = this;
                Fragment.load({
                    name: "ntt.hr.payroll.fragments.popup",
                    type: "XML",
                    id: 'supplier',
                    controller: this // Controller access is provided to the popup
                })
                    // Asynchronous - 1.Call back and 2.Promise
                    .then(function (oSupplier) { // this oPopup object is an object of Select dialog control of fragments view
                        that.oSupplierPopup = oSupplier
                        that.oSupplierPopup.setTitle("Select Supplier");
                        // provided access for fragment from the view to get to the model data 
                        that.getView().addDependent(that.oSupplierPopup);
                        that.oSupplierPopup.bindAggregation("items", {
                            path: '/supplier',
                            template: new sap.m.DisplayListItem({
                                label: '{name}',
                                value: '{city}'
                            })
                        });
                        that.oSupplierPopup.open();
                    });
            } else {
                this.oSupplierPopup.open();
            }
        }

    });
});