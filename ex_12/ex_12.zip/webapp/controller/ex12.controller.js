sap.ui.define(
    ['sap/ui/core/mvc/Controller'], 
    function(Controller){
        return Controller.extend("logger.controller.ex12",{

            onInit: function(){
            // Step 1. create a brand new model object
                var oModel = new sap.ui.model.json.JSONModel();

            // Step 2. Load or set the data to the model
                oModel.setData(
                    {
                        "empStr":{
                                "empId": 634,
                                "empName": "Carlisle",
                                "Salary": 450000,
                                "Currency": "USD"
                        },
                    
                        "empTab": [
                            {
                                "empId": 101,
                                "empName": "jane",
                                "salary": 250000,
                                "currency": "USD"
                            },
                            {
                                "empId": 102,
                                "empName": "jack",
                                "salary": 125000,
                                "currency": "USD"
                            },
                            {
                                "empId": 103,
                                "empName": "jerry",
                                "salary": 300000,
                                "currency": "DIN"
                            },
                        ]
                    }
                );

            // Step 3. Make the model aware to the application
                
                // - Model settiing at application level - available in all the views     
                sap.ui.getCore().setModel(oModel);   
                                
                 // - Model setting at View level - only specific to the view
                 //  this.getView().setModel(oModel);    

            // Step 4. Binding Syntax Type 3, 4 
           ////////////////////////////////////////////////////                            
                // BINDING type 3
                var oSalary = this.getView().byId("idSalary");
                oSalary.bindValue('/empStr/Salary');
                
                // BINDING type 4
                var oCurr = this.getView().byId("idCurrency");
                oCurr.bindProperty("value", "/empStr/Currency");
            },

            onLoad: function(){
                this.getView().byId("idEmpId").setValue("609879");
                this.getView().byId("idEmpName").setValue("Argnan Carlyle");
                this.getView().byId("idSalary").setValue("400000"); 
                this.getView().byId("idCurrency").setValue("USD");
            },

        });
});