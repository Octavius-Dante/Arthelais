// This is Scaffolding template 
sap.ui.define(
    ['sap/ui/core/mvc/Controller'],
    function (Controller) {
        return Controller.extend("spiderman.controller.Main", {

        });
    });