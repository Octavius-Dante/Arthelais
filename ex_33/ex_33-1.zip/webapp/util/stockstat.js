sap.ui.define([], () => {
    "use strict";
    return {
        statusText(sStatus) {
            switch (sStatus) {
                case "available":
                    return 'Success';
                case "out of stock":
                    return 'Warning';
                case "discontinued":
                    return 'Error';
                default:
                    return sStatus;
            }
        }
    };
});