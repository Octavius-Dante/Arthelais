sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("dante.demox.mybp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);